export interface VisualizationStep<TState = unknown> {
  codeLine: number;
  message: string;
  explanation?: string;
  state: TState;
}

export interface ExecutionSnapshot<TState = unknown> {
  step: VisualizationStep<TState> | null;
  index: number;
  total: number;
  canPrevious: boolean;
  canNext: boolean;
}

export interface VisualizationProps<TState> {
  step: VisualizationStep<TState> | null;
}
