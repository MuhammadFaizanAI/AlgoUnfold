import type { ComponentType } from "react"
import type { VisualizationProps, VisualizationStep } from "./types"
import { createArrayTraversalSteps } from "../algorithms/arrays/traversal/step"
import ArrayTraversalVisualization from "../../visualizations/arrays/ArrayTraversalVisualization"
import SinglyLinkedListVisualization
  from "../../visualizations/linked-lists/SinglyLinkedListVisualization";

import {
  createSinglyLinkedListTraversalSteps,
} from "../algorithms/linked-lists/singly/traversal/steps"

export interface VisualizationDefinition<TState = unknown> {
  createSteps: () => VisualizationStep<TState>[]
  Component: ComponentType<VisualizationProps<TState>>
}

const registry: Record<string, VisualizationDefinition<any>> = {
  "Array Traversal": {
    createSteps: createArrayTraversalSteps,
    Component: ArrayTraversalVisualization,
  },

  "Singly List Traversal": {
    createSteps: createSinglyLinkedListTraversalSteps,
    Component: SinglyLinkedListVisualization,
  },
};

export function getVisualization(
  topic: string
): VisualizationDefinition<any> | null {
  return registry[topic] ?? null
}
