import { useCallback, useEffect, useMemo, useState } from "react"
import { Executor } from "./executor"
import type { VisualizationStep } from "./types"

export function useExecution<TState>(steps: VisualizationStep<TState>[]) {
  const [index, setIndex] = useState(0)

  useEffect(() => {
    setIndex(0)
  }, [steps])

  const snapshot = useMemo(() => {
    const executor = new Executor(steps)
    for (let i = 0; i < index; i += 1) executor.next()
    return executor.snapshot
  }, [steps, index])

  return {
    ...snapshot,
    stepIndex: snapshot.index,
    activeLine: snapshot.step?.codeLine ?? null,
    next: useCallback(
      () => setIndex((i) => Math.min(Math.max(steps.length - 1, 0), i + 1)),
      [steps.length]
    ),
    previous: useCallback(() => setIndex((i) => Math.max(0, i - 1)), []),
    reset: useCallback(() => setIndex(0), []),
  }
}
