import type { ExecutionSnapshot, VisualizationStep } from "./types";

export class Executor<TState = unknown> {
  private index = 0;
  constructor(private readonly steps: VisualizationStep<TState>[] = []) {}

  get snapshot(): ExecutionSnapshot<TState> {
    const total = this.steps.length;
    return {
      step: total ? this.steps[this.index] : null,
      index: total ? this.index : 0,
      total,
      canPrevious: this.index > 0,
      canNext: this.index < total - 1,
    };
  }

  next(): void { if (this.index < this.steps.length - 1) this.index += 1; }
  previous(): void { if (this.index > 0) this.index -= 1; }
  reset(): void { this.index = 0; }
}
