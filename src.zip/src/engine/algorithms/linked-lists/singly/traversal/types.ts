export interface LinkedListNode {
  id: string
  value: number
  next: string | null
}

export interface SinglyLinkedListState {
  nodes: LinkedListNode[]
  head: string | null
  current: string | null
  visitedNodeIds: string[]
}
