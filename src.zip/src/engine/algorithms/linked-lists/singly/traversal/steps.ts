import type { VisualizationStep } from "../../../../core/types"
import type { LinkedListNode, SinglyLinkedListState } from "./types"

export function createSinglyLinkedListTraversalSteps(): VisualizationStep<SinglyLinkedListState>[] {
  const nodes: LinkedListNode[] = [
    { id: "node-1", value: 10, next: "node-2" },
    { id: "node-2", value: 20, next: "node-3" },
    { id: "node-3", value: 30, next: "node-4" },
    { id: "node-4", value: 40, next: null },
  ]

  const steps: VisualizationStep<SinglyLinkedListState>[] = []
  const head = nodes[0]?.id ?? null
  const visitedNodeIds: string[] = []

  steps.push({
    codeLine: 15,
    message: "The linked list is ready. HEAD references the first node; CURRENT is initialized to HEAD.",
    explanation: "A linked list is traversed by following each node’s next reference. CURRENT starts at HEAD, which points to the first node. No node has been visited yet.",
    state: { nodes, head, current: head, visitedNodeIds: [] },
  })

  let current = head
  while (current !== null) {
    const node = nodes.find((item) => item.id === current)
    if (!node) break

    steps.push({
      codeLine: 17,
      message: `CURRENT points to ${node.id}, which stores ${node.value}. The algorithm visits this value.`,
      explanation: `The while condition confirms CURRENT is not NULL. The expression current->data reads ${node.value} from the node currently referenced by CURRENT.`,
      state: {
        nodes,
        head,
        current,
        visitedNodeIds: [...visitedNodeIds],
      },
    })

    visitedNodeIds.push(current)
    current = node.next

    steps.push({
      codeLine: 18,
      message: current
        ? `Move CURRENT through the next reference to ${current}.`
        : "The final node's next reference is NULL, so traversal will finish.",
      explanation: current
        ? `The assignment current = current->next advances the pointer from ${node.id} to ${current}. The list links determine the next node; the array order is not used to traverse.`
        : `The assignment current = current->next sets CURRENT to NULL because ${node.id}.next is NULL. The next loop condition will fail.`,
      state: {
        nodes,
        head,
        current,
        visitedNodeIds: [...visitedNodeIds],
      },
    })
  }

  steps.push({
    codeLine: 21,
    message: "Traversal is complete. Every node has been visited and CURRENT is NULL.",
    explanation: "CURRENT is NULL, so the while loop terminates. Every node reachable from HEAD has been visited, and the traversal is complete.",
    state: { nodes, head, current: null, visitedNodeIds: [...visitedNodeIds] },
  })

  return steps
}
