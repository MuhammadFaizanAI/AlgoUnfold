import type { VisualizationStep } from "../../../core/types"

export interface ArrayTraversalState {
  array: number[]
  currentIndex: number
  visitedIndices: number[]
}

export function createArrayTraversalSteps(): VisualizationStep<ArrayTraversalState>[] {
  const array = [10, 20, 30, 40, 50]
  const steps: VisualizationStep<ArrayTraversalState>[] = []

  steps.push({
    codeLine: -1,
    message: "The array is ready. Traversal starts at the first element.",
    explanation: "An array stores elements at indexed positions. The loop begins at index 0 and advances one position at a time until i reaches the array size.",
    state: { array: [...array], currentIndex: -1, visitedIndices: [] },
  })

  for (let i = 0; i < array.length; i += 1) {
    steps.push({
      codeLine: 8,
      message: `The loop visits index ${i}, which contains ${array[i]}.`,
      explanation: `The loop variable i is ${i}. Accessing array[i] reads ${array[i]} from index ${i}. Previously visited indices remain marked so the learner can track progress.`,
      state: {
        array: [...array],
        currentIndex: i,
        visitedIndices: Array.from({ length: i }, (_, index) => index),
      },
    })
  }

  steps.push({
    codeLine: 10,
    message: "Traversal is complete. Every element has been visited.",
    explanation: "The loop has finished because its condition is no longer true. Every array index from 0 through the final index has been visited exactly once.",
    state: {
      array: [...array],
      currentIndex: -1,
      visitedIndices: array.map((_, i) => i),
    },
  })

  return steps
}
