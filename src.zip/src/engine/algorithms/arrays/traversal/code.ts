export const arrayTraversalCode = `const array = [10, 20, 30, 40, 50];

for (let i = 0; i < array.length; i++) {
  visit(array[i]);
}`
