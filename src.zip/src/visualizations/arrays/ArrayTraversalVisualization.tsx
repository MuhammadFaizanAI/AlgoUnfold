import { useMemo } from "react"
import { MarkerType, type Edge, type Node } from "@xyflow/react"
import type { VisualizationProps } from "../../engine/core/types"
import type { ArrayTraversalState } from "../../engine/algorithms/arrays/traversal/step"
import VisualizationCanvas from "../flow/VisualizationCanvas"
import type { DsaFlowNodeData } from "../flow/DsaFlowNode"

export default function ArrayTraversalVisualization({
  step,
}: VisualizationProps<ArrayTraversalState>) {
  const state = step?.state

  const { nodes, edges } = useMemo(() => {
    if (!state) return { nodes: [] as Node<DsaFlowNodeData>[], edges: [] as Edge[] }

    const flowNodes: Node<DsaFlowNodeData>[] = state.array.map((value, index) => {
      const active = state.currentIndex === index
      const visited = state.visitedIndices.includes(index)
      return {
        id: `array-index-${index}`,
        type: "dsaNode",
        position: { x: index * 145, y: 45 },
        draggable: false,
        selectable: false,
        focusable: false,
        data: {
          value,
          variant: "array",
          eyebrow: `INDEX ${index}`,
          detail: active ? "CURRENT ELEMENT" : undefined,
          active,
          visited,
          tags: active ? ["CURRENT"] : [],
          footerLeft: "array",
          footerRight: `[${index}]`,
        },
      }
    })

    const flowEdges: Edge[] = state.array.slice(0, -1).map((_, index) => ({
      id: `array-edge-${index}-${index + 1}`,
      source: `array-index-${index}`,
      target: `array-index-${index + 1}`,
      type: "straight",
      markerEnd: { type: MarkerType.ArrowClosed, color: state.visitedIndices.includes(index) ? "#4b9b8b" : "#536a8c" },
      style: {
        stroke: state.visitedIndices.includes(index) ? "#4b9b8b" : "#536a8c",
        strokeWidth: 1.8,
      },
      selectable: false,
    }))

    return { nodes: flowNodes, edges: flowEdges }
  }, [state])

  const summary = state
    ? state.currentIndex >= 0
      ? `Index ${state.currentIndex} · Value ${state.array[state.currentIndex]}`
      : `${state.array.length} elements · ${state.visitedIndices.length === state.array.length ? "Traversal complete" : "Ready to traverse"}`
    : "Waiting for a step"

  return (
    <VisualizationCanvas
      nodes={nodes}
      edges={edges}
      label="Array Traversal"
      summary={summary}
      className="array-flow-canvas"
    />
  )
}
