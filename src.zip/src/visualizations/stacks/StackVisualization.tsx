import type { VisualizationProps } from "../../engine/core/types";

export default function StackVisualization(_props: VisualizationProps) {
  return <div className="visualization-coming-soon"><strong>Stack</strong><span>Build this SVG visualization in this file.</span></div>;
}
