import type { VisualizationProps } from "../../engine/core/types";

export default function RecursionVisualization(_props: VisualizationProps) {
  return <div className="visualization-coming-soon"><strong>Recursion</strong><span>Build this SVG visualization in this file.</span></div>;
}
