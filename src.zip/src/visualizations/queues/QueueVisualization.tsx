import type { VisualizationProps } from "../../engine/core/types";

export default function QueueVisualization(_props: VisualizationProps) {
  return <div className="visualization-coming-soon"><strong>Queue</strong><span>Build this SVG visualization in this file.</span></div>;
}
