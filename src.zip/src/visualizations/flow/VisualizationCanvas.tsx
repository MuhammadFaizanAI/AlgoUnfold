import { useCallback, type MouseEvent } from "react"
import {
  Background,
  ReactFlow,
  ReactFlowProvider,
  type Edge,
  type Node,
  type NodeTypes,
  type FitViewOptions,
  useReactFlow,
} from "@xyflow/react"
import "@xyflow/react/dist/style.css"
import DsaFlowNode, { type DsaFlowNodeData } from "./DsaFlowNode"
import "./visualizationCanvas.css"

const sharedNodeTypes: NodeTypes = { dsaNode: DsaFlowNode }
const fitOptions: FitViewOptions = { padding: 0.28, minZoom: 0.45, maxZoom: 1.15 }

type Props = {
  nodes: Node<DsaFlowNodeData>[]
  edges: Edge[]
  label: string
  summary?: string
  className?: string
}

function CanvasContents({ nodes, edges, label, summary, className = "" }: Props) {
  const preventNodeInteraction = useCallback(() => {}, [])
  const { zoomIn, zoomOut, fitView } = useReactFlow()

  const handleZoomIn = useCallback((event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault()
    event.stopPropagation()
    void zoomIn({ duration: 180 })
  }, [zoomIn])

  const handleZoomOut = useCallback((event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault()
    event.stopPropagation()
    void zoomOut({ duration: 180 })
  }, [zoomOut])

  const handleCenter = useCallback((event: MouseEvent<HTMLButtonElement>) => {
    event.preventDefault()
    event.stopPropagation()
    void fitView({ ...fitOptions, duration: 250 })
  }, [fitView])

  return (
    <section className={`dsa-canvas ${className}`} aria-label={`${label} canvas`}>
      <div className="dsa-canvas__topbar">
        <div className="dsa-canvas__title-group">
          <span className="dsa-canvas__live-dot" />
          <span className="dsa-canvas__title">{label}</span>
        </div>
        <span className="dsa-canvas__summary">{summary ?? `${nodes.length} elements`}</span>
      </div>
      <div className="dsa-canvas__viewport">
        <ReactFlow
          nodes={nodes}
          edges={edges}
          nodeTypes={sharedNodeTypes}
          fitView
          fitViewOptions={fitOptions}
          minZoom={0.25}
          maxZoom={1.8}
          nodesDraggable={false}
          nodesConnectable={false}
          elementsSelectable={false}
          nodesFocusable={false}
          edgesFocusable={false}
          panOnDrag
          zoomOnScroll
          zoomOnPinch
          zoomOnDoubleClick={false}
          onNodeClick={preventNodeInteraction}
          proOptions={{ hideAttribution: true }}
        >
          <Background color="#263b58" gap={24} size={1} />
        </ReactFlow>
        <div className="dsa-canvas__manual-controls" role="group" aria-label="Canvas zoom controls">
          <button type="button" onClick={handleZoomIn} title="Zoom in" aria-label="Zoom in">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
          </button>
          <button type="button" onClick={handleZoomOut} title="Zoom out" aria-label="Zoom out">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14" /></svg>
          </button>
          <button type="button" onClick={handleCenter} title="Center diagram / fit view" aria-label="Center diagram">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5M8 8h8v8H8z" /></svg>
          </button>
        </div>
        {!nodes.length && (
          <div className="dsa-canvas__empty">
            <div className="dsa-canvas__empty-icon">∅</div>
            <strong>No visualization steps yet</strong>
            <span>This topic will use the same canvas when its visualizer is implemented.</span>
          </div>
        )}
      </div>
      <div className="dsa-canvas__footer">
        <span><i className="dsa-canvas__legend-dot dsa-canvas__legend-dot--active" /> Current</span>
        <span><i className="dsa-canvas__legend-dot dsa-canvas__legend-dot--visited" /> Visited</span>
        <span className="dsa-canvas__hint">Drag empty space to pan · Scroll to zoom · Center control fits the diagram</span>
      </div>
    </section>
  )
}

export default function VisualizationCanvas(props: Props) {
  return (
    <ReactFlowProvider>
      <CanvasContents {...props} />
    </ReactFlowProvider>
  )
}
