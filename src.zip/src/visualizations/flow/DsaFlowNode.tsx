import { Handle, Position, type NodeProps } from "@xyflow/react"

export type DsaFlowNodeData = {
  value: string | number
  eyebrow?: string
  detail?: string
  footerLeft?: string
  footerRight?: string
  active?: boolean
  visited?: boolean
  variant?: "array" | "list" | "null"
  tags?: string[]
}

export default function DsaFlowNode({ data }: NodeProps) {
  const item = data as unknown as DsaFlowNodeData
  const classes = [
    "dsa-flow-node",
    `dsa-flow-node--${item.variant ?? "default"}`,
    item.active ? "is-active" : "",
    item.visited ? "is-visited" : "",
  ].filter(Boolean).join(" ")

  return (
    <div className={classes}>
      <Handle type="target" position={Position.Left} className="dsa-flow-handle" />
      {(item.eyebrow || item.tags?.length) && (
        <div className="dsa-flow-node__eyebrow">
          {item.eyebrow && <span>{item.eyebrow}</span>}
          {item.tags?.map((tag) => <span className="dsa-flow-tag" key={tag}>{tag}</span>)}
        </div>
      )}
      <div className="dsa-flow-node__value">{item.value}</div>
      {item.detail && <div className="dsa-flow-node__detail">{item.detail}</div>}
      {(item.footerLeft || item.footerRight) && (
        <div className="dsa-flow-node__footer">
          <span>{item.footerLeft}</span>
          <span>{item.footerRight}</span>
        </div>
      )}
      <Handle type="source" position={Position.Right} className="dsa-flow-handle" />
    </div>
  )
}
