import type { VisualizationProps } from "../../engine/core/types";

export default function GraphVisualization(_props: VisualizationProps) {
  return <div className="visualization-coming-soon"><strong>Graph</strong><span>Build this SVG visualization in this file.</span></div>;
}
