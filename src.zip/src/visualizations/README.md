# AlgoUnfold visualization architecture

All implemented visualizations use the shared React Flow canvas in `visualizations/flow/VisualizationCanvas.tsx`.

## Responsibilities

- `engine/algorithms/**`: creates immutable `VisualizationStep` arrays. It owns algorithm logic and teaching state, never React Flow nodes.
- `engine/core/types.ts`: shared step contract (`codeLine`, `message`, optional `explanation`, and `state`).
- `visualizations/flow/VisualizationCanvas.tsx`: shared read-only React Flow viewport, background, zoom controls, fit/center control, and interaction policy.
- `visualizations/flow/DsaFlowNode.tsx`: shared node styling for array elements, linked-list nodes, pointers/tags, and NULL nodes.
- `visualizations/arrays/ArrayTraversalVisualization.tsx`: adapts array state into React Flow nodes and edges.
- `visualizations/linked-lists/SinglyLinkedListVisualization.tsx`: adapts linked-list state into nodes and actual `next` reference edges.
- `components/Workspace.tsx`: owns topic selection, code display, execution buttons, and the persistent per-step explanation panel.

## Adding another visualization

1. Define the data structure state and `createSteps()` in `engine/algorithms/<structure>/<operation>/`.
2. Keep each step's `codeLine` aligned with the displayed C++ source (line numbers are 1-based; use `-1` only when no line should be highlighted).
3. Add an `explanation` for the teaching point. If omitted, the Workspace shows `message`.
4. Create a small visualization adapter. Convert the step state into `Node<DsaFlowNodeData>[]` and `Edge[]`; do not create another React Flow instance or canvas.
5. Render `<VisualizationCanvas nodes={nodes} edges={edges} label="..." summary="..." />`.
6. Register the step generator and component in `engine/core/visualizationRegistry.tsx` using the exact sidebar topic key.

The canvas is intentionally read-only: users can pan and zoom, but cannot drag, select, or connect nodes. Algorithm steps are the source of truth.
