import { useMemo } from "react"
import { MarkerType, type Edge, type Node } from "@xyflow/react"
import type { VisualizationProps } from "../../engine/core/types"
import type { SinglyLinkedListState } from "../../engine/algorithms/linked-lists/singly/traversal/types"
import VisualizationCanvas from "../flow/VisualizationCanvas"
import type { DsaFlowNodeData } from "../flow/DsaFlowNode"

export default function SinglyLinkedListVisualization({
  step,
}: VisualizationProps<SinglyLinkedListState>) {
  const state = step?.state

  const { nodes, edges } = useMemo(() => {
    if (!state) return { nodes: [] as Node<DsaFlowNodeData>[], edges: [] as Edge[] }

    const flowNodes: Node<DsaFlowNodeData>[] = state.nodes.map((node, index) => {
      const active = state.current === node.id
      const visited = state.visitedNodeIds.includes(node.id)
      const tags: string[] = []
      if (state.head === node.id) tags.push("HEAD")
      if (active) tags.push("CURRENT")

      return {
        id: node.id,
        type: "dsaNode",
        position: { x: index * 205, y: 48 },
        draggable: false,
        selectable: false,
        focusable: false,
        data: {
          value: node.value,
          variant: "list",
          eyebrow: `NODE ${index + 1}`,
          detail: `id: ${node.id}`,
          footerLeft: "data",
          footerRight: `next: ${node.next ?? "NULL"}`,
          active,
          visited,
          tags,
        },
      }
    })

    const tail = state.nodes[state.nodes.length - 1]
    if (tail) {
      flowNodes.push({
        id: "__null__",
        type: "dsaNode",
        position: { x: state.nodes.length * 205, y: 65 },
        draggable: false,
        selectable: false,
        focusable: false,
        data: {
          value: "NULL",
          variant: "null",
          eyebrow: "END OF LIST",
          detail: "no next node",
        },
      })
    }

    const flowEdges: Edge[] = state.nodes.flatMap((node) => {
      const target = node.next ?? "__null__"
      const active = state.current === node.id
      return [{
        id: `${node.id}->${target}`,
        source: node.id,
        target,
        type: "smoothstep",
        animated: active,
        markerEnd: { type: MarkerType.ArrowClosed, color: active ? "#b6a2ff" : "#7189ac" },
        style: {
          stroke: active ? "#a78bfa" : state.visitedNodeIds.includes(node.id) ? "#3d9a87" : "#7189ac",
          strokeWidth: active ? 2.8 : 2,
        },
        selectable: false,
      }]
    })

    return { nodes: flowNodes, edges: flowEdges }
  }, [state])

  const summary = state
    ? `${state.visitedNodeIds.length} of ${state.nodes.length} nodes visited`
    : "Waiting for a step"

  return (
    <VisualizationCanvas
      nodes={nodes}
      edges={edges}
      label="Singly Linked List · Traversal"
      summary={summary}
      className="linked-list-flow-canvas"
    />
  )
}
