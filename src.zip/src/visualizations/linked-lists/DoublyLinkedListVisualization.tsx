import type { VisualizationProps } from "../../engine/core/types";

export default function DoublyLinkedListVisualization(_props: VisualizationProps) {
  return <div className="visualization-coming-soon"><strong>Doubly Linked List</strong><span>Build this SVG visualization in this file.</span></div>;
}
