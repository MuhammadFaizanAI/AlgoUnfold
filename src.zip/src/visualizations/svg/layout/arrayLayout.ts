import type { NodeLayout } from "./layoutTypes";
export function getArrayLayout(count:number):NodeLayout[] {
 const width=120,gap=42,startX=90,y=245;
 return Array.from({length:count},(_,index)=>({x:startX+index*(width+gap),y,width,height:72}));
}
