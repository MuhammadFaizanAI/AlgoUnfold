export interface Point { x:number; y:number; }
export interface NodeLayout extends Point { width:number; height:number; }
