import type { ReactNode } from "react"
export default function SVGStage({
  viewBox = "0 0 1200 600",
  width = 1200,
  height = 600,
  children,
  className = "",
}: {
  viewBox?: string
  width?: number
  height?: number
  children: ReactNode
  className?: string
}) {
  return (
    <svg
      className={className}
      viewBox={viewBox}
      width={width}
      height={height}
      role="img"
      aria-label="Data structure visualization"
      preserveAspectRatio="xMidYMid meet"
    >
      {children}
    </svg>
  )
}
