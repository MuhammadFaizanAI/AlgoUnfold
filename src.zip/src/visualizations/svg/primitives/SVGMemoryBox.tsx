export default function SVGMemoryBox({
  x,
  y,
  address,
  value,
}: {
  x: number
  y: number
  address: string
  value: string | number
}) {
  return (
    <g opacity=".9">
      <rect
        x={x}
        y={y}
        width="170"
        height="58"
        rx="9"
        fill="#0b1220"
        stroke="#26364e"
      />
      <text x={x + 12} y={y + 21} fill="#64748b" fontSize="11">
        MEMORY
      </text>
      <text
        x={x + 12}
        y={y + 42}
        fill="#a5b4fc"
        fontSize="12"
        fontFamily="monospace"
      >
        {address}
      </text>
      <text x={x + 112} y={y + 34} fill="#e2e8f0" fontSize="14">
        {value}
      </text>
    </g>
  )
}
