export default function SVGNull({ x, y }: { x: number; y: number }) {
  return (
    <text x={x} y={y} fill="#64748b" fontSize="13" fontFamily="monospace">
      NULL
    </text>
  )
}
