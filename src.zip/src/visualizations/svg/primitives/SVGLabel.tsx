export default function SVGLabel({
  x,
  y,
  children,
  color = "#94a3b8",
  size = 14,
  weight = 500,
}: {
  x: number
  y: number
  children: string
  color?: string
  size?: number
  weight?: number
}) {
  return (
    <text
      x={x}
      y={y}
      fill={color}
      fontSize={size}
      fontWeight={weight}
      fontFamily="Inter, sans-serif"
    >
      {children}
    </text>
  )
}
