export default function SVGArrow({
  x1,
  y1,
  x2,
  y2,
  color = "#64748b",
}: {
  x1: number
  y1: number
  x2: number
  y2: number
  color?: string
}) {
  return (
    <g>
      <line x1={x1} y1={y1} x2={x2} y2={y2} stroke={color} strokeWidth="2.5" />
      <path
        d={`M ${x2 - 8} ${y2 - 5} L ${x2} ${y2} L ${x2 - 8} ${y2 + 5}`}
        fill="none"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </g>
  )
}
