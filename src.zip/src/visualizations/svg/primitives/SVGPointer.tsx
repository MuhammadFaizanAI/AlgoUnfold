export default function SVGPointer({
  x,
  y,
  label,
  color = "#c084fc",
}: {
  x: number
  y: number
  label: string
  color?: string
}) {
  return (
    <g>
      <text
        x={x}
        y={y}
        textAnchor="middle"
        fill={color}
        fontSize="14"
        fontWeight="700"
      >
        {label}
      </text>
      <path
        d={`M ${x} ${y + 8} L ${x} ${y + 28}`}
        stroke={color}
        strokeWidth="2"
      />
      <path
        d={`M ${x - 5} ${y + 22} L ${x} ${y + 29} L ${x + 5} ${y + 22}`}
        fill="none"
        stroke={color}
        strokeWidth="2"
      />
    </g>
  )
}
