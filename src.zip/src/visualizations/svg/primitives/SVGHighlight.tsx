export default function SVGHighlight({
  x,
  y,
  width,
  height,
  color = "#8b5cf6",
}: {
  x: number
  y: number
  width: number
  height: number
  color?: string
}) {
  return (
    <rect
      x={x}
      y={y}
      width={width}
      height={height}
      rx="14"
      fill="none"
      stroke={color}
      strokeWidth="2"
      strokeDasharray="6 5"
    />
  )
}
