export default function SVGNode({
  x,
  y,
  width = 120,
  height = 72,
  value,
  label,
  active = false,
  visited = false,
}: {
  x: number
  y: number
  width?: number
  height?: number
  value: string | number
  label?: string
  active?: boolean
  visited?: boolean
}) {
  return (
    <g>
      <rect
        x={x}
        y={y}
        width={width}
        height={height}
        rx="12"
        fill={active ? "#4f46e5" : visited ? "#182b4a" : "#111827"}
        stroke={active ? "#a78bfa" : visited ? "#4b6fa8" : "#334155"}
        strokeWidth={active ? 2.5 : 1.5}
      />
      <text
        x={x + width / 2}
        y={y + height / 2 + 9}
        textAnchor="middle"
        fill="#f8fafc"
        fontSize="25"
        fontFamily="Cascadia Code, Fira Code, monospace"
        fontWeight="650"
      >
        {value}
      </text>
      {label && (
        <text
          x={x + width / 2}
          y={y + height + 25}
          textAnchor="middle"
          fill="#64748b"
          fontSize="13"
          fontFamily="Inter, sans-serif"
        >
          {label}
        </text>
      )}
    </g>
  )
}
