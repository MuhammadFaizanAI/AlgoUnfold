export function animatedStyle(duration=320) {
 return { transition:`all ${duration}ms cubic-bezier(.2,.75,.25,1)` };
}
