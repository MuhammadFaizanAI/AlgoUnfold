export const SVG_ANIMATION = { fast:180, normal:320, slow:520 } as const;
export function clamp(value:number,min:number,max:number) { return Math.max(min,Math.min(max,value)); }
