export type EasingName = "linear" | "easeInOut" | "easeOut";
export interface AnimationConfig { duration:number; easing?:EasingName; }
