import { linkedListExamples } from "./examples"
import type { LanguageId } from "./languages"

const linkedListVariants: Record<string, Record<LanguageId, string>> = {
  "Doubly Linked List": {
    cpp: `#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev = nullptr;
    Node* next = nullptr;
    explicit Node(int value) : data(value) {}
};

bool insertAt(Node*& head, int index, int value) {
    if (index < 0) return false;
    Node* node = new Node(value);
    if (index == 0) {
        node->next = head;
        if (head) head->prev = node;
        head = node;
        return true;
    }
    Node* current = head;
    for (int i = 0; current && i < index - 1; ++i)
        current = current->next;
    if (!current) { delete node; return false; }
    node->next = current->next;
    node->prev = current;
    if (current->next) current->next->prev = node;
    current->next = node;
    return true;
}`,
    rust: `#[derive(Debug)]
struct Node {
    value: i32,
    previous: Option<usize>,
    next: Option<usize>,
}

// Arena-backed doubly linked list: indexes replace raw pointers.
struct DoublyLinkedList {
    nodes: Vec<Node>,
    head: Option<usize>,
    tail: Option<usize>,
}

// TODO: implement insert_at and maintain both links.`,
    python: `class Node:
    def __init__(self, value):
        self.value = value
        self.prev = None
        self.next = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at(self, index, value):
        if index < 0:
            raise IndexError(index)
        node = Node(value)
        if index == 0:
            node.next = self.head
            if self.head:
                self.head.prev = node
            self.head = node
            return
        current = self.head
        for _ in range(index - 1):
            if current is None:
                raise IndexError(index)
            current = current.next
        if current is None:
            raise IndexError(index)
        node.next = current.next
        node.prev = current
        if current.next:
            current.next.prev = node
        current.next = node`,
    typescript: `class DoublyNode {
  previous: DoublyNode | null = null;
  next: DoublyNode | null = null;
  constructor(public value: number) {}
}

class DoublyLinkedList {
  head: DoublyNode | null = null;

  insertAt(index: number, value: number): void {
    if (!Number.isInteger(index) || index < 0) throw new RangeError();
    const node = new DoublyNode(value);
    if (index === 0) {
      node.next = this.head;
      if (this.head) this.head.previous = node;
      this.head = node;
      return;
    }
    let current = this.head;
    for (let i = 0; i < index - 1; i++) current = current?.next ?? null;
    if (!current) throw new RangeError();
    node.next = current.next;
    node.previous = current;
    if (current.next) current.next.previous = node;
    current.next = node;
  }
}`,
    java: `class DoublyLinkedList {
    static class Node {
        int value;
        Node prev, next;
        Node(int value) { this.value = value; }
    }
    Node head;

    void insertAt(int index, int value) {
        if (index < 0) throw new IndexOutOfBoundsException();
        Node node = new Node(value);
        if (index == 0) {
            node.next = head;
            if (head != null) head.prev = node;
            head = node;
            return;
        }
        Node current = head;
        for (int i = 0; i < index - 1 && current != null; i++)
            current = current.next;
        if (current == null) throw new IndexOutOfBoundsException();
        node.next = current.next;
        node.prev = current;
        if (current.next != null) current.next.prev = node;
        current.next = node;
    }
}`,
  },
  "Circular Linked List": {
    cpp: `#include <iostream>
using namespace std;

struct Node {
    int value;
    Node* next;
    explicit Node(int v) : value(v), next(nullptr) {}
};

void insertAtHead(Node*& tail, int value) {
    Node* node = new Node(value);
    if (!tail) {
        node->next = node;
        tail = node;
        return;
    }
    node->next = tail->next;
    tail->next = node;
}
`,
    rust: `struct Node {
    value: i32,
    next: usize,
}

// Index-based circular list avoids self-referential references.
struct CircularList {
    nodes: Vec<Node>,
    tail: Option<usize>,
}

// TODO: implement insertion and keep tail.next == head.`,
    python: `class Node:
    def __init__(self, value):
        self.value = value
        self.next = None

class CircularList:
    def __init__(self):
        self.tail = None

    def insert_head(self, value):
        node = Node(value)
        if self.tail is None:
            node.next = node
            self.tail = node
            return
        node.next = self.tail.next
        self.tail.next = node`,
    typescript: `class Node {
  next: Node | null = null;
  constructor(public value: number) {}
}

class CircularList {
  tail: Node | null = null;

  insertHead(value: number) {
    const node = new Node(value);
    if (!this.tail) {
      node.next = node;
      this.tail = node;
      return;
    }
    node.next = this.tail.next;
    this.tail.next = node;
  }
}`,
    java: `class CircularList {
    static class Node {
        int value;
        Node next;
        Node(int value) { this.value = value; }
    }
    Node tail;

    void insertHead(int value) {
        Node node = new Node(value);
        if (tail == null) {
            node.next = node;
            tail = node;
            return;
        }
        node.next = tail.next;
        tail.next = node;
    }
}`,
  },
}

const comment: Record<LanguageId, string> = {
  cpp: "//",
  rust: "//",
  python: "#",
  typescript: "//",
  java: "//",
}

/** Static source samples; no compilation or execution. */
export function getTopicSource(topic: string, language: LanguageId): string {
  if (topic === "Singly List Traversal") {
    return `#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* head = new Node{10, nullptr};
    head->next = new Node{20, nullptr};
    head->next->next = new Node{30, nullptr};
    head->next->next->next = new Node{40, nullptr};

    Node* current = head;
    while (current != nullptr) {
        cout << current->data << endl;
        current = current->next;
    }

    return 0;
}`
  }
  if (topic === "Array Traversal") {
    const source: Record<LanguageId, string> = {
      cpp: `#include <iostream>\nusing namespace std;\n\nint main() {\n    int array[] = {10, 20, 30, 40, 50};\n    int size = 5;\n    for (int i = 0; i < size; i++) {\n        cout << array[i] << endl;\n    }\n}`,
      rust: `fn main() {\n    let array = [10, 20, 30, 40, 50];\n\n    for i in 0..array.len() {\n        println!(\"{}\", array[i]);\n    }\n}`,
      python: `array = [10, 20, 30, 40, 50]\n\nfor i in range(len(array)):\n    print(array[i])`,
      typescript: `const array: number[] = [10, 20, 30, 40, 50];\n\nfor (let i = 0; i < array.length; i++) {\n    console.log(array[i]);\n}`,
      java: `public class Main {\n    public static void main(String[] args) {\n        int[] array = {10, 20, 30, 40, 50};\n\n        for (int i = 0; i < array.length; i++) {\n            System.out.println(array[i]);\n        }\n    }\n}`,
    }
    return source[language]
  }
  if (topic === "Singly Linked List") return linkedListExamples[language]
  const variant = linkedListVariants[topic]
  if (variant) return variant[language]
  const note = `${comment[language]} ${topic}\n${comment[language]} Add your algorithm here when you implement its engine.`
  switch (language) {
    case "cpp":
      return `#include <iostream>\n#include <vector>\nusing namespace std;\n\n${note}\n\nint main() {\n    vector<int> values = {12, 24, 36};\n    return 0;\n}`
    case "rust":
      return `${note}\n\nfn main() {\n    let values = vec![12, 24, 36];\n    println!("{:?}", values);\n}`
    case "python":
      return `${note}\n\nvalues = [12, 24, 36]\nprint(values)`
    case "typescript":
      return `${note}\n\nconst values: number[] = [12, 24, 36];\nconsole.log(values);`
    case "java":
      return `${note}\n\npublic class Main {\n    public static void main(String[] args) {\n        int[] values = {12, 24, 36};\n        System.out.println(values.length);\n    }\n}`
  }
}
