export const languages = [
 { id: 'cpp', label: 'C++', file: 'main.cpp' },
 { id: 'rust', label: 'Rust', file: 'main.rs' },
 { id: 'python', label: 'Python', file: 'main.py' },
 { id: 'typescript', label: 'TypeScript', file: 'main.ts' },
 { id: 'java', label: 'Java', file: 'Main.java' },
] as const;
export type LanguageId = typeof languages[number]['id'];
