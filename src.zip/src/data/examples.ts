import type { LanguageId } from "./languages"

export const linkedListExamples: Record<LanguageId, string> = {
  cpp: `#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
    explicit Node(int value) : data(value), next(nullptr) {}
};

bool insertAt(Node*& head, int index, int value) {
    if (index < 0) return false;
    if (index == 0) {
        Node* node = new Node(value);
        node->next = head;
        head = node;
        return true;
    }
    Node* current = head;
    for (int i = 0; current && i < index - 1; ++i)
        current = current->next;
    if (!current) return false;
    Node* node = new Node(value);
    node->next = current->next;
    current->next = node;
    return true;
}`,
  rust: `#[derive(Debug)]
struct Node {
    value: i32,
    next: Option<Box<Node>>,
}

fn insert_at(head: &mut Option<Box<Node>>, index: usize, value: i32) -> bool {
    let mut cursor = head;
    for _ in 0..index {
        match cursor {
            Some(node) => cursor = &mut node.next,
            None => return false,
        }
    }
    let next = cursor.take();
    *cursor = Some(Box::new(Node { value, next }));
    true
}`,
  python: `class Node:
    def __init__(self, value, next_node=None):
        self.value = value
        self.next = next_node

def insert_at(head, index, value):
    if index < 0:
        raise IndexError("Negative index")
    if index == 0:
        return Node(value, head)

    current = head
    for _ in range(index - 1):
        if current is None:
            raise IndexError("Index out of range")
        current = current.next

    if current is None:
        raise IndexError("Index out of range")
    current.next = Node(value, current.next)
    return head`,
  typescript: `class ListNode {
  constructor(
    public value: number,
    public next: ListNode | null = null
  ) {}
}

function insertAt(
  head: ListNode | null,
  index: number,
  value: number
): ListNode | null {
  if (!Number.isInteger(index) || index < 0)
    throw new RangeError("Invalid index");
  if (index === 0) return new ListNode(value, head);

  let current = head;
  for (let i = 0; i < index - 1; i++) {
    if (!current) throw new RangeError("Out of range");
    current = current.next;
  }
  if (!current) throw new RangeError("Out of range");
  current.next = new ListNode(value, current.next);
  return head;
}`,
  java: `class LinkedList {
    static class Node {
        int value;
        Node next;
        Node(int value) { this.value = value; }
    }

    Node head;

    void insertAt(int index, int value) {
        if (index < 0) throw new IndexOutOfBoundsException();
        Node node = new Node(value);
        if (index == 0) {
            node.next = head;
            head = node;
            return;
        }
        Node current = head;
        for (int i = 0; i < index - 1; i++) {
            if (current == null) throw new IndexOutOfBoundsException();
            current = current.next;
        }
        if (current == null) throw new IndexOutOfBoundsException();
        node.next = current.next;
        current.next = node;
    }
}`,
}
