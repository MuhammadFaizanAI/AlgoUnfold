export type Step = { id: string; label?: string; value?: string | number; status?: 'active' | 'visited' | 'default' };
export type ExecutionControls = {
  onPrevious: () => void;
  onNext: () => void;
  onReset: () => void;
  canPrevious: boolean;
  canNext: boolean;
};
// Connect these controls to your own execution engine later.
