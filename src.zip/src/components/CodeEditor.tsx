import { useEffect, useMemo, useRef, useState } from "react"
import Prism from "prismjs"
import "prismjs/components/prism-clike"
import "prismjs/components/prism-c"
import "prismjs/components/prism-cpp"
import Icon from "./Icon"
import { SiCplusplus } from "react-icons/si"

const grammar = Prism.languages.cpp ?? Prism.languages.clike

function tokenNode(
  token: string | Prism.Token,
  key: number | string
): React.ReactNode {
  if (typeof token === "string") return token
  const children = Array.isArray(token.content)
    ? token.content.map((child, i) => tokenNode(child, i))
    : typeof token.content === "string"
      ? token.content
      : tokenNode(token.content, "inner")
  return (
    <span key={key} className={"token " + token.type}>
      {children}
    </span>
  )
}
export default function CodeEditor({
  code,
  activeLine,
}: {
  code: string
  activeLine: number | null
}) {
  const [copied, setCopied] = useState(false)
  const scrollRef = useRef<HTMLDivElement>(null)
  const activeRef = useRef<HTMLDivElement>(null)
  const lines = useMemo(
    () => code.split("\n").map((line) => Prism.tokenize(line || " ", grammar)),
    [code],
  )
  useEffect(() => {
    activeRef.current?.scrollIntoView({ block: "center", behavior: "smooth" })
  }, [activeLine, code])
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: 0, left: 0 })
  }, [code])
  async function copy() {
    try {
      await navigator.clipboard.writeText(code)
      setCopied(true)
      setTimeout(() => setCopied(false), 1200)
    } catch {
      setCopied(false)
    }
  }
  return (
    <div className="static-code-shell">
      <div className="editor-tabbar">
        <div className="file-tab">
          <span className="language-logo cpp"><SiCplusplus size={17} aria-hidden="true" /></span>
          <span>main.cpp</span>
          <span className="language-label">C++</span>
        </div>
        <div className="editor-actions">
          <button
            className="copy-button"
            onClick={copy}
            title="Copy source code"
          >
            <Icon name={copied ? "check" : "copy"} size={15} />
            <span>{copied ? "Copied" : "Copy"}</span>
          </button>
        </div>
      </div>
      <div
        className="static-code-scroll"
        ref={scrollRef}
        role="region"
        aria-label="Read-only syntax-highlighted source code"
        tabIndex={0}
      >
        <div className="static-code-lines">
          {lines.map((tokens, index) => (
            <div
              key={index}
              ref={activeLine === index + 1 ? activeRef : undefined}
              className={
                "static-code-line " +
                (activeLine === index + 1 ? "highlighted" : "")
              }
            >
              <span className="static-line-number">{index + 1}</span>
              <span className="static-line-content">
                {tokens.map((token, i) => tokenNode(token, i))}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
