import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import CodeEditor from "./CodeEditor"
import Icon from "./Icon"
import { getTopicSource } from "../data/topicSource"
import { getVisualization } from "../engine/core/visualizationRegistry"
import { useExecution } from "../engine/core/useExecution"
import VisualizationCanvas from "../visualizations/flow/VisualizationCanvas"

const MIN_PANEL = 190

export default function Workspace({ topic }: { topic: string }) {
  const [mode, setMode] = useState<"both" | "code" | "visual">("both")
  const [split, setSplit] = useState(40)
  const [vertical, setVertical] = useState(false)
  const workspaceRef = useRef<HTMLElement>(null)
  const dragRef = useRef<{
    start: number
    split: number
    dimension: number
  } | null>(null)
  const code = getTopicSource(topic, "cpp")
  const definition = useMemo(() => getVisualization(topic), [topic])
  const steps = useMemo(() => definition?.createSteps() ?? [], [definition])
  const playback = useExecution(steps)

  useEffect(() => {
    const el = workspaceRef.current
    if (!el) return
    const observer = new ResizeObserver(([entry]) => {
      const { width, height } = entry.contentRect
      setVertical(width < 760 || (width < 1050 && height > width * 1.15))
    })
    observer.observe(el)
    return () => observer.disconnect()
  }, [])

  const move = useCallback(
    (event: PointerEvent) => {
      const drag = dragRef.current
      if (!drag) return
      const delta = (vertical ? event.clientY : event.clientX) - drag.start
      const next = drag.split + (delta / drag.dimension) * 100
      const minimum = (MIN_PANEL / drag.dimension) * 100
      if (next < minimum * 0.65) {
        setMode("visual")
        return
      }
      if (next > 100 - minimum * 0.65) {
        setMode("code")
        return
      }
      setMode("both")
      setSplit(Math.max(minimum, Math.min(100 - minimum, next)))
    },
    [vertical]
  )

  const stopDrag = useCallback(() => {
    dragRef.current = null
    document.body.classList.remove("is-resizing")
  }, [])
  useEffect(() => {
    window.addEventListener("pointermove", move)
    window.addEventListener("pointerup", stopDrag)
    window.addEventListener("pointercancel", stopDrag)
    return () => {
      window.removeEventListener("pointermove", move)
      window.removeEventListener("pointerup", stopDrag)
      window.removeEventListener("pointercancel", stopDrag)
    }
  }, [move, stopDrag])

  function beginDrag(event: React.PointerEvent<HTMLDivElement>) {
    const rect = workspaceRef.current?.getBoundingClientRect()
    if (!rect) return
    dragRef.current = {
      start: vertical ? event.clientY : event.clientX,
      split,
      dimension: vertical ? rect.height : rect.width,
    }
    document.body.classList.add("is-resizing")
  }
  function toggle(panel: "code" | "visual") {
    setMode((current) => (current === panel ? "both" : panel))
  }
  function restore() {
    setMode("both")
    setSplit(40)
  }
  const Visualizer = definition?.Component
  const effectiveSplit = Math.max(25, Math.min(70, split))

  return (
    <main
      ref={workspaceRef}
      className={`workspace ${vertical ? "stacked" : ""} mode-${mode}`}
      style={{ "--split": `${effectiveSplit}%` } as React.CSSProperties}
    >
      <section className="panel code-panel">
        <div className="panel-header">
          <div className="panel-heading">
            <span className="panel-icon code-icon">
              <Icon name="code" />
            </span>
            <strong>Code</strong>
          </div>
          <button
            className="panel-max icon-btn"
            onClick={() => toggle("code")}
            title={mode === "code" ? "Restore panels" : "Focus code"}
          >
            <Icon name={mode === "code" ? "restore" : "maximize"} />
          </button>
        </div>
        <CodeEditor
          key={topic}
          code={code}
          activeLine={playback.activeLine}
        />
      </section>

      {mode === "both" && (
        <div
          className="splitter"
          role="separator"
          tabIndex={0}
          aria-label="Resize code and visualization panels"
          onPointerDown={beginDrag}
          onDoubleClick={restore}
        >
          <span className="splitter-grip">
            <Icon name="grip" />
          </span>
        </div>
      )}

      <section className="panel visual-panel">
        <div className="panel-header">
          <div className="panel-heading">
            <span className="panel-icon visual-icon">
              <Icon name="layers" />
            </span>
            <strong>Visualization</strong>
            <span className="active-topic">{topic}</span>
          </div>
          <div className="panel-buttons">
            {mode !== "both" && (
              <button
                className="icon-btn"
                onClick={restore}
                title="Show both panels"
              >
                <Icon name="columns" />
              </button>
            )}
            <button
              className="icon-btn"
              onClick={() => toggle("visual")}
              title={
                mode === "visual" ? "Restore panels" : "Focus visualization"
              }
            >
              <Icon name={mode === "visual" ? "restore" : "maximize"} />
            </button>
          </div>
        </div>

        <div className="visual-content">
          <div className="visual-stage">
            {Visualizer ? (
              <Visualizer step={playback.step} />
            ) : (
              <VisualizationCanvas
                nodes={[]}
                edges={[]}
                label={topic}
                summary="Visualization not implemented yet"
              />
            )}
          </div>
        </div>

        <aside className="visual-info-card" aria-live="polite">
          <span className="visual-info-icon">
            <Icon name="info" size={16} />
          </span>
          <div className="visual-info-body">
            <div className="visual-info-heading">
              Step explanation
              {playback.total > 0 && (
                <span className="explanation-step-count">
                  Step {playback.stepIndex + 1} of {playback.total}
                </span>
              )}
            </div>
            <p>
              {playback.step?.explanation ?? playback.step?.message ??
                "Choose an implemented topic to see a step-by-step explanation here."}
            </p>
            {playback.step && playback.step.codeLine > 0 && (
              <span className="explanation-code-line">
                <Icon name="code" size={12} /> C++ line {playback.step.codeLine}
              </span>
            )}
          </div>
        </aside>

        <div className="playback">
          <div className="step-count">
            Step <b>{playback.total ? playback.stepIndex + 1 : 0}</b>
            <span>/</span>
            {playback.total}
          </div>
          <div className="playback-actions">
            <button
              onClick={playback.reset}
              className="reset-btn"
              title="Reset"
            >
              <Icon name="reset" />
              <span>Reset</span>
            </button>
            <button
              onClick={playback.previous}
              disabled={!playback.canPrevious}
              title="Previous step"
            >
              <Icon name="previous" />
              <span>Previous</span>
            </button>
            <button
              onClick={playback.next}
              disabled={!playback.canNext}
              className="next-btn"
              title="Next step"
            >
              <span>Next</span>
              <Icon name="next" />
            </button>
          </div>
        </div>
      </section>

      {mode !== "both" && (
        <button
          className="floating-restore"
          onClick={restore}
          title="Restore both panels"
        >
          <Icon name="columns" />
          <span>Split view</span>
        </button>
      )}
    </main>
  )
}
