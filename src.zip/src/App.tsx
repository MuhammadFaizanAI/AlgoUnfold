import { useState } from "react"
import TitleBar from "./components/TitleBar"
import Sidebar from "./components/Sidebar"
import Workspace from "./components/Workspace"
import { allTopics } from "./data/topics"
export default function App() {
  const [topic, setTopic] = useState(allTopics[0])
  const [sidebarOpen, setSidebarOpen] = useState(false)
  return (
    <div className="app">
      <TitleBar onMenu={() => setSidebarOpen((v) => !v)} />
      <div className="app-body">
        <Sidebar
          active={topic}
          onSelect={setTopic}
          open={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
        />
        <Workspace topic={topic} />
      </div>
    </div>
  )
}
